<!-- sidebar -->
<aside class="sidebar">

	<?php get_template_part('/template-parts/searchform'); ?>

</aside>
<!-- /sidebar -->