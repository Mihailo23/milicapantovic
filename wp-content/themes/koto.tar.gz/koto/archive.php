<?php get_header(); ?>

	<h1>
		Archives
	</h1>

	<?php get_template_part('/template-parts/loop'); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>