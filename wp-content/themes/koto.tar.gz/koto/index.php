<?php get_header(); ?>

	<h1>
		Latest Posts
	</h1>

	<?php get_template_part('/template-parts/loop'); ?>

<?php get_sidebar(); ?>

<?php get_footer(); ?>