<?php /* Template Name: Gallery Page Template */ get_header(); ?>

<?php get_footer(); ?>