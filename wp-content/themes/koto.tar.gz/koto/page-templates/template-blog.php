<?php /* Template Name: Blog Page Template */ get_header(); ?>

<?php get_footer(); ?>